const SHOP = "https://betterware.com.mx";
const HEADERS = { "user-agent": "Mozilla/5.0 (compatible; BetterwareCatalog/1.0)", "accept": "application/json,text/plain,*/*" };
const plain = (html = "") => String(html).replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/\s+/g, " ").trim();
const money = (cents) => cents == null || !Number.isFinite(Number(cents)) ? null : Math.round(Number(cents)) / 100;

export default async (request) => {
  const url = new URL(request.url);
  const sku = (url.searchParams.get("sku") || "").trim();
  if (!sku || sku.length > 80) return Response.json({ error: "Código SKU inválido." }, { status: 400 });
  try {
    const suggestUrl = new URL(`${SHOP}/search/suggest.json`);
    suggestUrl.searchParams.set("q", sku);
    suggestUrl.searchParams.set("resources[type]", "product");
    suggestUrl.searchParams.set("resources[limit]", "10");
    suggestUrl.searchParams.set("resources[options][unavailable_products]", "show");
    const sr = await fetch(suggestUrl, { headers: HEADERS, signal: AbortSignal.timeout(12000) });
    if (!sr.ok) throw new Error(`La búsqueda oficial respondió ${sr.status}.`);
    const suggestions = await sr.json();
    const found = suggestions?.resources?.results?.products || [];
    if (!found.length) return Response.json({ error: "Betterware no devolvió productos para ese SKU.", sku }, { status: 404 });

    const productSuggestion = found.find(p => (p.variants || []).some(v => String(v.sku || "").trim().toLowerCase() === sku.toLowerCase() || String(v.barcode || "").trim() === sku));
    if (!productSuggestion) return Response.json({ error: "La búsqueda encontró resultados, pero ninguno coincide exactamente con el SKU/código escaneado.", sku }, { status: 404 });
    const productPath = new URL(productSuggestion.url, SHOP).pathname.replace(/\/$/, "") + ".js";
    let product = null;
    const pr = await fetch(new URL(productPath, SHOP), { headers: HEADERS, signal: AbortSignal.timeout(12000) });
    if (pr.ok) product = await pr.json();
    const variants = product?.variants || productSuggestion.variants || [];
    const variant = variants.find(v => String(v.sku || "").trim().toLowerCase() === sku.toLowerCase() || String(v.barcode || "").trim() === sku) || variants[0] || null;
    const suggestionAmount = (value) => {
      if (value == null) return null;
      const parsed = Number(String(value).replace(/[^0-9.,]/g, "").replace(/,(?=\d{3}(?:\D|$))/g, "").replace(",", "."));
      return Number.isFinite(parsed) ? parsed : null;
    };
    // The product .js endpoint returns integer cents; predictive-search fallback
    // values are display-formatted currency and must not be divided by 100.
    const price = variant?.price ?? product?.price;
    const compare = variant?.compare_at_price ?? product?.compare_at_price;
    let regularPrice = null, promoPrice = null;
    if (price != null) {
      regularPrice = compare != null && Number(compare) > Number(price) ? money(compare) : money(price);
      promoPrice = compare != null && Number(compare) > Number(price) ? money(price) : null;
    } else {
      regularPrice = suggestionAmount(productSuggestion.price);
      promoPrice = suggestionAmount(productSuggestion.compare_at_price);
      if (promoPrice != null && regularPrice != null && promoPrice > regularPrice) [regularPrice, promoPrice] = [promoPrice, regularPrice];
    }
    const body = product?.description || productSuggestion.body || productSuggestion.body_html || "";
    const handle = product?.handle || productSuggestion.url?.split("/").filter(Boolean).pop() || "";
    const officialUrl = `${SHOP}/products/${encodeURIComponent(handle)}?pws=veromedina`;
    const image = product?.featured_image || productSuggestion.image || product?.images?.[0] || null;
    const name = product?.title || productSuggestion.title || "";
    const variantsSku = variant?.sku || "";
    if (!name) return Response.json({ error: "La ficha no contiene nombre de producto.", sku }, { status: 404 });
    return Response.json({
      sku, name, description: plain(body), image, url: officialUrl,
      regularPrice, promoPrice,
      promoNote: promoPrice != null ? "Se detectó precio comparativo en la ficha. Confirma condiciones y vigencia en Betterware; las promociones condicionadas pueden no aparecer en los datos técnicos." : "Verifica en la ficha oficial si existe una promoción condicionada o vigente.",
      matchedSku: variantsSku, source: "Betterware", checkedAt: new Date().toISOString()
    }, { headers: { "cache-control": "public, max-age=300" } });
  } catch (error) {
    return Response.json({ error: `No fue posible consultar Betterware: ${error.message}` }, { status: 502 });
  }
};
